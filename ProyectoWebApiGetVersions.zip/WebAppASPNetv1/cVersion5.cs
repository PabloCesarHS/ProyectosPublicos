﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;

namespace WebAppASPNetv1
{
    public void cVersion5()
    {
        var client = HttpClient.Create("http://example.com/api");

        // get some companies!
        var companies = client.Get("companies").OnOk().As<List<Company>>();

        // upload a company, with validation error support
        client.Post(company, "companies")
        .On(HttpStatusCode.BadRequest, (List<ValidationError> errors) => {
                Console.WriteLine("Ruh Roh, you have {0} validation errors", errors.Count());
            })
        .On(HttpStatusCode.Created, () => Console.WriteLine("Holy moly you win!"));
    
        // update a company
        client.Put(company, "company/:id", new { id = "awesome-sauce" })
            .OnOk(() => Console.WriteLine("Company updated"));
        
        // run a search
        client.Get("images/:category", new { category = "cats", breed = "omg the cutest", size = "kittens" })
            .OnOk().As<List<Image>>();

        // make an asynchronous request
        var response = await client.GetAsync("companies/:id", new { id = 5 })
        response.OnOk(UpdateCompaniesCallback);
    }
}